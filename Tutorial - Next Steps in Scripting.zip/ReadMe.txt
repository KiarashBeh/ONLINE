﻿The content in this tutorial reflects the Qlik Sense Desktop user interface and there are some differences compared to Qlik Sense. However, you should still be able to take the tutorial on Qlik Sense. Before you can begin the tutorial, preparations must be done depending on installation.  

With a Qlik Sense Desktop installation verify that you have Qlik Sense Desktop installed, then open the PDF and begin the tutorial!

With a Qlik Sense installation you must ask your system administrator to: 
1. Give you access to the hub, using the QMC.
2. Store the Tutorial source folder on the server machine.
3. Ensure that the server has the correct Access database engine installed.
4. Load the data.
Now you can open the PDF and begin the tutorial!